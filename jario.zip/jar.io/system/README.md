# Installing on Windows

First make sure you have JDK 1.8 installed, Powershell installed, and also Maven installed. 

Then, to run the project on Windows, follow these steps:

1. If you do not have powershell installed, install Powershell.
8. Then to build the project type:
9. .\build.cmd
10. After the build completes, to run the project type:
11. .\run_server.cmd

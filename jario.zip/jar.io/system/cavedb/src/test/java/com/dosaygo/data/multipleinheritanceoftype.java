public class multipleinheritanceoftype {
  public interface A {}
  public interface B {}
  public interface C extends A, B {}
  public class z {}
}

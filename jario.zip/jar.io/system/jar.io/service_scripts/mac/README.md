# Todo:

- Make all scripts follow the formats specified in their services.

java -jar jar.io/target/jar.io-1.0-alpha-jar-with-dependencies.jar $env:homepath




